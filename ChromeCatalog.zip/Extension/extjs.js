//console.log(document.getElementsByTagName('body')[0].innerHTML);
//console.log($(body).html());
showDPLA();

